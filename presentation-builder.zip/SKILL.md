---
name: presentation-builder
description: Transform video scripts into beautiful, Apple-inspired HTML presentations with glass morphism design, strategic color psychology, and sequential animations optimized for YouTube content creators.
---

# Presentation Builder

Transform video scripts into beautiful, Apple-inspired HTML presentations optimized for YouTube content creators.

## What This Skill Does

Takes a video script and creates a complete, professional HTML presentation with:
- Glass morphism design aesthetic (Cluely style)
- Strategic color psychology (red=problems, green=solutions, cyan=technology)
- Sequential animations controlled by spacebar
- Mobile-responsive layouts
- Lead magnet CTA integration
- Perfect centering and typography

## Target Audience Understanding

**Who you're designing for:**
- Non-technical entrepreneurs
- People who understand business, not code
- Seeking opportunities, not features
- Skeptical of hype, value authenticity
- Want results and actionable insights

## Core Design Philosophy

### Visual Style
- **Backgrounds**: Neutral only (white, off-white, light gray, subtle gradients, black for drama)
- **Color Usage**: Let content colors speak against neutral backgrounds
- **Inspiration**: Apple's minimalist yet bold approach
- **Avoid**: Bright neon, tacky highlighters, cheap effects

### Color Psychology (CRITICAL)

**Red = Negative/Old/Bad Way**
- Old methods being replaced
- Expensive options (employees vs software)
- Problems and pain points
- Manual/inefficient processes
- Warning badges (`badge-danger`)
- "Before" states in comparisons

**Examples:**
- Employee costs in comparison charts
- Manual tracking (Excel, paper forms)
- Broken systems (5 apps for 1 job)
- Time-wasting processes
- Hiring headaches

**Green = Positive/New/Good Way**
- Solutions you're offering
- Cost-effective options (tailored software)
- Benefits and improvements
- Automated/efficient processes
- Success badges (`badge-success`)
- "After" states in comparisons

**Examples:**
- Software costs in comparisons
- Automated solutions (one unified system)
- Streamlined workflows
- Time-saving processes
- 24/7 reliable solutions

**Cyan/Blue = Your Solution/Technology**
- Claude Code references
- AI/technology elements
- Your offering highlights
- Innovation indicators
- Primary actions (`badge-primary`)

### Typography & Copy Principles

**Headlines**: Short, bold, impactful - focus on benefits in layman's terms
- Wrong: "124GB storage"
- Right: "10,000 photos in your pocket"

**Subheadlines**: Maximum 2 lines, supporting technical details

**Steve Jobs Simplification**: Benefits over features always

## Content Structure Rules

### Slide Density
- **Mic Drop Moments**: Big ideas get their own slide
- **Lists**: Same category items (dentists, gyms) = one slide; Distinct ideas = separate slides
- **Maximum Elements**: 12 cards/points per slide (prefer much less)

### New Slide Triggers
Watch for these phrases in scripts:
- "But..." - transition/bridge
- "Therefore..." - conclusion
- "Here's the thing..." - new idea
- New paragraph feeling
- Contrasts (old way vs new way)

### Content Transformation Examples

**Script**: "Opus 4.1 scored 74.5% on SWE benchmark, which means it's as good as a senior developer"

**Slide**:
- Headline: "As Good as a Senior Developer"
- Subheadline: "74.5% SWE Benchmark Score"

**Script**: "Build once, hand them the keys, sell forever"

**Slide**: Three cards or pills: "Build Once" | "Hand Over Keys" | "Sell Forever"

## CSS Layout Standards (MANDATORY)

### Container Structure
```css
/* Stage container - exact dimensions */
.stage {
    width: min(1400px, calc(100vw - 80px));
    height: min(800px, calc(100vh - 160px));
    border-radius: 30px;
}

/* Slide system - mandatory centering */
.slide {
    padding: 80px 40px 100px 40px; /* NEVER exceed 100px vertical */
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    gap: 15px;
    max-height: calc(100vh - 220px);
    overflow: hidden;
}

.slide .content {
    max-width: 1100px;
    text-align: center;
    width: 100%;
    display: flex; /* REQUIRED for proper centering */
    flex-direction: column;
    align-items: center;
    justify-content: center;
    max-height: calc(100vh - 260px);
}
```

### Typography Hierarchy (STRICT LIMITS)
```css
h1 {
    font-size: clamp(36px, 5vw, 60px); /* MAX 60px */
    line-height: 1.2;
    margin: 0 0 15px 0;
    font-weight: 900;
}

h2 {
    font-size: clamp(18px, 2.2vw, 24px); /* MAX 24px */
    font-weight: 600;
    margin: 8px 0 25px 0;
    line-height: 1.4;
}

.big {
    font-size: clamp(20px, 2.8vw, 28px); /* MAX 28px */
    font-weight: 700;
    line-height: 1.4;
    margin: 15px 0;
}

.huge {
    font-size: clamp(42px, 6vw, 72px); /* MAX 72px - use sparingly */
    font-weight: 900;
    line-height: 1.1;
    margin: 10px 0;
}
```

### Perfect Centering Requirements
```css
/* All grids and panels MUST use auto margins */
.comparison-grid, .examples-grid, .metal-panel, .panel {
    margin: 20px auto; /* REQUIRED for centering */
    max-width: 900px;
}

.comparison-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 25px; /* Never exceed 30px */
}

.examples-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 20px;
}
```

### Component Sizing Standards
```css
/* Chips and badges - consistent sizing */
.chip, .metal-chip, .badge {
    padding: 8px 16px; /* Never exceed 12px 20px */
    font-size: 14px; /* Never exceed 16px */
    margin: 4px;
    border-radius: 50px;
}

/* Cards - proper spacing */
.card, .compare-card, .example-card {
    padding: 25px 20px; /* Never exceed 40px */
    border-radius: 16px;
}

/* Panels - controlled padding */
.panel, .metal-panel {
    padding: 30px 25px; /* Never exceed 40px */
    border-radius: 20px;
    max-width: 950px;
    width: 100%;
}
```

### Glass Morphism Style (Cluely Reference)
```css
.glass-card {
    background: rgba(255, 255, 255, 0.75);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(255, 255, 255, 0.3);
    border-radius: 16px;
    padding: 25px 20px;
}

.gradient-text {
    background: linear-gradient(135deg, #22d3ee 0%, #06b6d4 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-weight: 900;
}

.glow-text {
    color: #22d3ee;
    text-shadow: 0 0 20px rgba(34, 211, 238, 0.5);
}
```

### Mobile Responsive (MANDATORY)
```css
@media (max-width: 768px) {
    .slide {
        padding: 40px 25px;
        gap: 15px;
    }
    h1 { font-size: clamp(28px, 8vw, 48px); }
    h2 { font-size: clamp(16px, 4vw, 20px); }

    /* All grids become single column */
    .comparison-grid, .examples-grid {
        grid-template-columns: 1fr;
        gap: 20px;
    }
}
```

## Animation System

### Core Animation Principles
- Elements fade up from below (translateY(30px) to 0)
- Smooth timing: 0.6-0.8s with ease-out
- Stagger delays: 0.1-0.2s between elements
- Replay animations when going back

### Sequential Animations for Multi-Element Slides

**When to use**: Slides with 3+ badges, comparison cards, list items, step-by-step processes

**Animation Types:**
- **Standard Sequential** (0.2s delay) - Default for most multi-element slides
- **Surprise Reveals** (0.5s delay, scale + fade) - Dramatic numbers/statistics
- **Building Anticipation** (0.3-0.4s staggered) - Building toward conclusion
- **Number Animations** - Count up from 0 to final value
- **Transformation Animations** - Before/after morphs

### Critical Implementation

**IMPORTANT: Nested Elements Must Be Animated Separately**

When comparison cards or containers have badges inside:
1. First animate the parent container
2. Then animate each child element sequentially
3. Example: Card → Badge 1 → Badge 2 → Badge 3

**Initial State Management:**
- ALL animatable elements start with `opacity: 0`
- Only add `.animate-in` class when animation triggers
- Never use CSS that auto-shows elements

### Keyboard Controls (CRITICAL)
- **Space bar** or **Right arrow**: Next animation within slide
- **Left arrow**: Previous slide (replay all animations)
- When animations complete, next key press moves to next slide

### Animation Implementation Template
```javascript
// Track animation state per slide
let currentAnimationStep = 0;
let slideAnimations = {};

// Example: Comparison cards with nested badges
slideAnimations[2] = [
    // Animate parent first
    () => slides[2].querySelectorAll('.comparison-card')[0].classList.add('animate-in'),
    // Then children sequentially
    () => slides[2].querySelectorAll('.comparison-card')[0].querySelectorAll('.badge')[0].classList.add('animate-in'),
    () => slides[2].querySelectorAll('.comparison-card')[0].querySelectorAll('.badge')[1].classList.add('animate-in'),
    // Second card
    () => slides[2].querySelectorAll('.comparison-card')[1].classList.add('animate-in'),
    () => slides[2].querySelectorAll('.comparison-card')[1].querySelectorAll('.badge')[0].classList.add('animate-in')
];

// Initialize non-animated slides
function initializeSlideElements(slideIndex) {
    const slide = slides[slideIndex];
    const hasAnimations = slideAnimations[slideIndex];

    if (!hasAnimations) {
        // Show content immediately on non-animated slides
        slide.querySelectorAll('.badge, .card, .comparison-card').forEach(el => {
            el.classList.add('animate-in');
        });
    }
}

// Keyboard handler
document.addEventListener('keydown', (e) => {
    if (e.key === ' ' || e.key === 'ArrowRight') {
        e.preventDefault();
        nextAction();
    } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        if (currentSlide > 0) scrollToSlide(currentSlide - 1);
    }
});
```

## Common Presentation Patterns

### Comparisons
Always side-by-side cards with color psychology:
- Left card: Red border/accents (old way/problem)
- Right card: Green border/accents (new way/solution)

### Problem/Solution
Visual contrast using red vs green badges and borders

### Before/After
Old World (red accents) vs New World (green accents) format

### Cost Comparisons
- Red bars/cards for expensive options
- Green bars for affordable solutions
- Show dramatic difference visually

### Data Visualization
Bar charts, pie charts, or big number cards with color coding

## Lead Magnet CTA Slide (MANDATORY FINAL SLIDE)

**Every presentation MUST end with this structure:**

### CTA Formula
1. **Headline**: "Get The Complete [Title]" or "Download The [Resource Name]"
2. **Subheadline**: Clear value proposition - "Everything you need to [achieve result]"
3. **Benefits List**: 5-6 specific, tangible benefits with cyan checkmarks (✓)
4. **Strong CTA Button**: "Download The Playbook →" with enhanced glow effect
5. **Trust Element**: "Free instant download. No spam, ever."

### Content Guidelines
**DO Include:**
- Specific numbers ("20+ Discovery Questions", "50+ Prompts")
- Templates, checklists, formulas
- Step-by-step processes
- Time-bound results ("30-Day Action Plan")

**DON'T Include:**
- Generic promises ("learn the secrets")
- Unverified community claims
- Vague benefits
- Multiple CTAs

### Example Implementation
```html
<div class="slide">
    <div class="content">
        <h1>Get The Complete <span class="glow-text">Playbook</span></h1>
        <h2>Everything you need to close your first $15K client</h2>

        <div class="glass-card" style="max-width: 700px; margin: 30px auto;">
            <h3 style="color: #22d3ee; margin-bottom: 20px;">The $15K Software Tailor Playbook Includes:</h3>
            <div style="text-align: left; font-size: 18px; line-height: 2;">
                <div><span style="color: #22d3ee; font-weight: bold;">✓</span> 20+ Discovery Questions to Uncover Client Needs</div>
                <div><span style="color: #22d3ee; font-weight: bold;">✓</span> Exact Pricing Formula (Never Undercharge Again)</div>
                <div><span style="color: #22d3ee; font-weight: bold;">✓</span> 50+ Claude Code Prompts Ready to Copy-Paste</div>
                <div><span style="color: #22d3ee; font-weight: bold;">✓</span> Client Proposal Template That Closes Deals</div>
                <div><span style="color: #22d3ee; font-weight: bold;">✓</span> 30-Day Action Plan to Your First Client</div>
                <div><span style="color: #22d3ee; font-weight: bold;">✓</span> 10 Niche Ideas With Proven Demand</div>
            </div>
        </div>

        <a href="#" class="cta-button" style="
            display: inline-block;
            background: linear-gradient(135deg, #22d3ee 0%, #06b6d4 100%);
            color: white;
            padding: 18px 40px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: bold;
            font-size: 20px;
            margin: 30px 0 15px 0;
            box-shadow: 0 8px 25px rgba(34, 211, 238, 0.4);
            transition: all 0.3s ease;
        ">Download The Playbook →</a>

        <p style="font-size: 14px; opacity: 0.7; margin-top: 10px;">
            Free instant download. No spam, ever.
        </p>
    </div>
</div>
```

## Tone Adaptation

### Urgent/Warning Content
- Black or dark backgrounds
- Red accents
- Bold, stark typography
- Sharp animations

### Opportunity/Exciting Content
- White/light backgrounds
- Blues and greens
- Smooth, welcoming animations
- "Breath of fresh air" feeling

### Educational Content
- Clean, professional
- Purple/blue accents
- Clear hierarchy
- Methodical reveals

## Quality Checklist

Before completing any presentation, verify:
- ✅ All content perfectly centered horizontally and vertically
- ✅ Typography follows strict size hierarchy (never exceed maximums)
- ✅ Consistent spacing throughout (15-25px gaps)
- ✅ All grids and panels use `margin: auto`
- ✅ No duplicate text effects or visual artifacts
- ✅ Mobile responsive with single-column layouts
- ✅ Content stays within safe zones (120px top, 140px bottom)
- ✅ No overlap with navigation dots or progress bar
- ✅ All content visible without scrolling on 768px+ screens
- ✅ Color psychology applied correctly (red=problems, green=solutions, cyan=tech)
- ✅ Lead magnet CTA slide is final slide with compelling benefits
- ✅ Sequential animations work smoothly with spacebar control
- ✅ Professional appearance matching reference quality

## FORBIDDEN Practices
- ❌ NO `::after` pseudo-elements for duplicate text effects
- ❌ NO font sizes larger than specified maximums
- ❌ NO slide padding greater than 100px vertical
- ❌ NO content without proper flexbox centering
- ❌ NO grids/panels without `margin: auto`
- ❌ NO overlapping or cramped elements
- ❌ NO missing responsive breakpoints
- ❌ NO content that gets cut off at viewport edges
- ❌ NO bright neon backgrounds or tacky colors
- ❌ NO generic ending slides - always use lead magnet CTA

## Slide Limit Guidelines
- **Target**: 15-20 slides
- **Maximum**: 35 slides (only for complex topics)
- If script is too long, suggest split points

## Workflow

1. **Read the script**: Understand the full narrative/journey
2. **Identify key moments**: Mic drop moments get their own slides
3. **Apply color psychology**: Red for problems, green for solutions, cyan for tech
4. **Design slides**: Use Cluely glass morphism style with perfect centering
5. **Add animations**: Sequential reveals for multi-element slides
6. **Create lead magnet CTA**: Final slide with compelling benefits
7. **Quality check**: Run through entire checklist above
8. **Save to**: `/Finished Presentations/[script-name].html`

## Example Color Usage in Context

**Cost Comparison Slide:**
```html
<div class="comparison-grid">
    <!-- Red = Expensive/Problem -->
    <div class="glass-card" style="border: 2px solid rgba(239, 68, 68, 0.5);">
        <h3>Hiring Employees</h3>
        <div class="badge badge-danger">$75K+ salary</div>
        <div class="badge badge-danger">Benefits & taxes</div>
        <div class="badge badge-danger">Training time</div>
        <div class="badge badge-danger">Turnover risk</div>
    </div>

    <!-- Green = Affordable/Solution -->
    <div class="glass-card" style="border: 2px solid rgba(34, 197, 94, 0.5);">
        <h3>Custom Software</h3>
        <div class="badge badge-success">$15K one-time</div>
        <div class="badge badge-success">No ongoing costs</div>
        <div class="badge badge-success">Instant deployment</div>
        <div class="badge badge-success">Never quits</div>
    </div>
</div>
```

**Solution Highlight:**
```html
<div class="glass-card" style="border: 2px solid rgba(34, 211, 238, 0.5);">
    <div class="badge badge-primary">Claude Code</div>
    <h2>Your Secret Weapon</h2>
    <p>Build professional software in hours, not months</p>
</div>
```

## Remember

You're not just creating slides - you're crafting an experience. The presentation should feel alive, engaging, and like a friend sharing an exciting opportunity. Never salesy or pushy.

Design serves the message, not the other way around.
